<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

get_header();
?>



<div class="inner_hero_back d-flex align-items-center justify-content-center">
        <?php dynamic_sidebar('service_banner') ?>
        <div class="container">
            <h1><?php the_title();?></h1>
            <ul class="bedcrumb d-flex justify-content-center">
                <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
                <li><?php the_title();?></li>
            </ul>
        </div>
    </div>
<div class="services_back single">
        <div class="container">
            <div class="main_back">
                <?php
                    // Start the Loop.
                    while ( have_posts() ) :
                        the_post();

                        get_template_part( 'template-parts/content/content-single', 'single' );

                    endwhile; // End the loop.
                    ?>
            </div>
        </div>
    </div>


<?php
get_footer();
