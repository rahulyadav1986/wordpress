<?php
/*
Template Name: Welcome Template
*/
get_header();
?>

<?php
    while ( have_posts() ) :
    the_post();
?>
  
  <?php require_once('template-parts/banner.php') ?>
  <?php require_once('template-parts/home_about.php') ?>
  <?php require_once('template-parts/why_best.php') ?>
  <?php require_once('template-parts/before_after_images.php') ?>
  <?php require_once('template-parts/home_services.php') ?>
  <?php require_once('template-parts/get_in_touch.php') ?>
  

<?php endwhile; ?>   
<?php

get_footer();
?>