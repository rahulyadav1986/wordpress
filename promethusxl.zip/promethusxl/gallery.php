<?php
/*
Template Name: Gallery Template
*/
get_header();
?>

    <?php
        while ( have_posts() ) :
        the_post();
    ?>

<div class="inner_hero_back d-flex align-items-center justify-content-center">
        <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-hero-banner',true);?>" alt="">
        <div class="container">
            <h1><?php the_title();?></h1>
            <ul class="bedcrumb d-flex justify-content-center">
                <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
                <li><?php the_title();?></li>
            </ul>
        </div>
    </div>

    <div class="default_body">
        <div class="container">
            <div class="gallery_back">
                <?php
                $args = array(
                    'numberposts' => -1,
                    'offset' => 0,
                    'orderby' => 'post_date',
                    'order' => 'ASC',
                    'include' => '',
                    'exclude' => '',
                    'meta_key' => '',
                    'meta_value' => '',
                    'post_type' => 'galleries',
                    'post_status' => 'draft, publish, future, pending, private',
                    'suppress_filters' => true
                    );
                    $j = 1;
                    $gallery = wp_get_recent_posts( $args, ARRAY_A );
                    foreach ( $gallery as $gallery ) {
                    $title = ($gallery['post_title']);
                    $image = wp_get_attachment_image_src( get_post_thumbnail_id( $gallery[ 'ID' ] ), 'single-post-thumbnail' );
                
                ?>   
                <div class="portion">
                    <a href="<?php echo $image[0] ?>" data-fancybox="gallery" data-caption="<?php echo $title ?>">
                        <img src="<?php echo $image[0] ?>" alt="">
                        <div class="overlay d-flex justify-content-center align-items-center">
                            <h3><?php echo $title ?></h3>
                        </div>
                    </a>
                </div>
                <?php $j++;} ?>
                
            </div>
        </div>
    </div>

    <?php endwhile; ?> 


<?php

get_footer();
?>
