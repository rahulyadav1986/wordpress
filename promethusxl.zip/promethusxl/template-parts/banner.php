<div class="clear"></div>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <ul class="carousel-indicators">
            <?php
              $args = array(
                'numberposts' => -1,
                'offset' => 0,
                'orderby' => 'post_date',
                'order' => 'ASC',
                'include' => '',
                'exclude' => '',
                'meta_key' => '',
                'meta_value' => '',
                'post_type' => 'banner',
                'post_status' => 'draft, publish, future, pending, private',
                'suppress_filters' => true
                );
                $j = 0;
                $banner = wp_get_recent_posts( $args, ARRAY_A );
                foreach ( $banner as $banner ) {        
            
            ?>
            <li data-target="#carouselExampleControls" data-slide-to="<?php echo $j;?>"
                class="<?php if($j==1) {?>active <?php }?>"></li>
            <?php $j++;} ?>

        </ul>
        <div class="carousel-inner">
            <?php
              $args = array(
                'numberposts' => -1,
                'offset' => 0,
                'orderby' => 'post_date',
                'order' => 'ASC',
                'include' => '',
                'exclude' => '',
                'meta_key' => '',
                'meta_value' => '',
                'post_type' => 'banner',
                'post_status' => 'draft, publish, future, pending, private',
                'suppress_filters' => true
                );
                $j = 1;
                $banner = wp_get_recent_posts( $args, ARRAY_A );
                foreach ( $banner as $banner ) {
                $excerpt = ($banner['post_excerpt']);
                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $banner[ 'ID' ] ), 'single-post-thumbnail' );
            
            ?>
            <div class="carousel-item <?php if($j==1) {?>active <?php }?>">
                <div class="hero_back d-flex align-items-center">
                    <img src="<?php echo $image[0] ?>" alt="">
                    <div class="container">
                        <div class="details">
                            <h2><?php echo get_post_meta($banner['ID'],'wpcf-custom-heading',true);?></h2>
                            <p><?php echo $excerpt; ?></p>
                            <div class="custom_button">
                                <a href="<?php echo get_post_meta($banner['ID'],'wpcf-button-url',true);?>">
                                    <span></span>
                                    <?php echo get_post_meta($banner['ID'],'wpcf-button-text',true);?>
                                    <img src="<?php echo get_post_meta($banner['ID'],'wpcf-button-icon',true);?>"
                                        alt="">
                                </a>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
            <?php $j++;} ?>
        </div>
    </div>





