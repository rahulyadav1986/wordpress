<div class="get_touch_back">
        <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-get-in-touch-background-image',true);?>" class="avator" alt="">
        <div class="container">
            <h2><?php echo get_post_meta(get_the_ID(),'wpcf-get-in-touch-heading',true);?></h2>
            <div class="row">
                <div class="col-lg-5">
                    <?php echo do_shortcode('[contact-form-7 id="27" title="Get in Touch Form"]') ?>
                </div>
            </div>
            

        </div>
    </div>