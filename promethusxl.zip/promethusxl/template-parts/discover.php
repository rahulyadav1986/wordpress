<section class="custom-about-us discover" id="care">
	<div class="container">
	<div class="row">
		<div class="col-lg-5 col-md-12 pr-0 pl-1 align-self-center inherit">
			<div class="about-us-img-caro">
				<div id="discover-owl" class="owl-carousel owl-theme">
				<?php $ix_result = get_post_meta(get_the_ID(),'wpcf-discover-slider',true);
		   
					$part_1 = str_replace('[gallery ids="',"",$ix_result);
					$part_2 = str_replace('"]',"",$part_1);
					
					//print_r($part_2);
					
					$gallery_ids = explode(',', $part_2);
						foreach ($gallery_ids as $gallery_id)
						{
						
						$feat_image_url = wp_get_attachment_url( $gallery_id );
					
					?>
					<div class="item about-img-item">
						<img src="<?php echo $feat_image_url ?>" alt="">
					</div>
				<?php } ?>
					
					
				</div>
			</div>
		</div>
		<div class="col-lg-7 col-md-12 pl-5 align-self-center">
			<div class="about-us-content">
				<div class="about-heading">
					<h6>[ <?php echo get_post_meta(get_the_ID(),'wpcf-discover-sub-heading',true);?> ]</h6>
					<h2><?php echo get_post_meta(get_the_ID(),'wpcf-discover-heading',true);?></h2>
				</div>
                <?php echo get_post_meta(get_the_ID(),'wpcf-discover-content',true);?>	
				<a href="<?php echo get_post_meta(get_the_ID(),'wpcf-discover-button-url',true);?>" class="custom-btn"><?php echo get_post_meta(get_the_ID(),'wpcf-discover-button-text',true);?></a>
			</div>
		</div>
		
		
	</div>
		
	</div>
</section>
