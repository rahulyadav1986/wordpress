<section class="client_logo">
	<div class="container">
		<div class="client_logo owl-carousel owl-theme" id="client">
            <?php
                $args = array(
                'numberposts' => -1,
                'offset' => 0,
                'orderby' => 'post_date',
                'order' => 'ASC',
                'include' => '',
                'exclude' => '',
                'meta_key' => '',
                'meta_value' => '',
                'post_type' => 'client',
                'post_status' => 'draft, publish, future, pending, private',
                'suppress_filters' => true
                );
                $j = 1;
                $client = wp_get_recent_posts( $args, ARRAY_A );
                foreach ( $client as $client ) {
                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $client[ 'ID' ] ), 'single-post-thumbnail' );
            ?>
			    <div class="item"><img src="<?php echo $image[0] ?>" alt=""></div>
            <?php $j++;} ?>
			
		</div>
	</div>
</section>