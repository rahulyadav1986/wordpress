<section class="testimonial" id="reviews">
	<div class="container">
		<div class="about-heading text-center">
			<h6>[ <?php echo get_post_meta(get_the_ID(),'wpcf-testimonial-sub-heading',true);?> ]</h6>
			<h2><?php echo get_post_meta(get_the_ID(),'wpcf-testimonial-heading',true);?></h2>
		</div>
		<div class="main_testimonials owl-carousel owl-theme" id="testimonial">
        <?php
            $args = array(
            'numberposts' => -1,
            'offset' => 0,
            'orderby' => 'post_date',
            'order' => 'ASC',
            'include' => '',
            'exclude' => '',
            'meta_key' => '',
            'meta_value' => '',
            'post_type' => 'testimonial',
            'post_status' => 'draft, publish, future, pending, private',
            'suppress_filters' => true
            );
            $j = 1;
            $testimonial = wp_get_recent_posts( $args, ARRAY_A );
            foreach ( $testimonial as $testimonial ) {
            $content = ($testimonial['post_content']);
            $image = wp_get_attachment_image_src( get_post_thumbnail_id( $testimonial[ 'ID' ] ), 'single-post-thumbnail' );

        ?>
			<div class="item">
				<div class="portion">
					<div class="image_back"><img src="<?php echo $image[0] ?>" alt=""></div>
					<p><?php echo $content ?></p>
				</div>
			</div>
        <?php $j++;} ?>
		</div>
	</div>
</section>






