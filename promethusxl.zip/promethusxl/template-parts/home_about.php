<div class="about_us_back">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="portion e_left">
                        <h1><?php echo get_post_meta(get_the_ID(),'wpcf-about-heading',true);?></h1>
                        <div class="custom_button">
                            <a href="<?php echo get_post_meta(get_the_ID(),'wpcf-about-button-url',true);?>">
                                <span></span>
                                <?php echo get_post_meta(get_the_ID(),'wpcf-about-button-text',true);?>
                                <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-about-button-icon',true);?>" alt="">
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="portion">
                        <p class="demo big"><?php echo get_post_meta(get_the_ID(),'wpcf-about-text-column-one',true);?></p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="portion">
                        <p class="demo"><?php echo get_post_meta(get_the_ID(),'wpcf-about-text-column-two',true);?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
