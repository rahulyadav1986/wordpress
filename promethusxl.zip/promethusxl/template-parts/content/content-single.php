<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

?>
<div class="portion">
	<div class="row">
		<div class="col-lg-4">
			<?php twentynineteen_post_thumbnail(); ?>
		</div>
		<div class="col-lg-8">
			<h3><?php the_title(); ?></h3>
			<p><?php the_content(); ?></p>
		</div>
	</div>
</div>
 
