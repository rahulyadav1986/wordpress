<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

?>
<div class="col-lg-4">
	<div class="portion">
		<?php twentynineteen_post_thumbnail(); ?>
		<h3><?php the_title(); ?></h3>
		<p><?php the_excerpt(); ?></p>
		<div class="custom_button">
			<a href="<?php the_permalink(); ?>">
				<span></span>
				LEARN MORE
				<img src="<?php echo get_template_directory_uri(); ?>/images/b1-arrow.png" alt="">
			</a>
		</div>
	</div>
</div>