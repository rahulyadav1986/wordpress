<section class="facts_back" id="solutions">
	<div class="container">
		<div class="row">
			<div class="col-md-6 order-2 order-lg-1">
				<div class="content_area">
					<div class="about-heading">
						<h6>[ <?php echo get_post_meta(get_the_ID(),'wpcf-facts-sub-heading',true);?> ]</h6>
						<h2><?php echo get_post_meta(get_the_ID(),'wpcf-facts-heading',true);?></h2>
					</div>
                    <?php echo get_post_meta(get_the_ID(),'wpcf-facts-content',true);?>					
					<a href="<?php echo get_post_meta(get_the_ID(),'wpcf-fact-button-url',true);?>" class="custom-btn"><?php echo get_post_meta(get_the_ID(),'wpcf-fact-button-text',true);?></a>
				</div>
			</div>
			<div class="col-md-6 order-1 order-lg-2">
				<img src="<?php echo get_post_meta(get_the_ID(),'wpcf-facts-image',true);?>" alt="">
			</div>
		</div>
	</div>
</section>