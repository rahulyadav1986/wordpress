<section class="video_back">
	<div class="container">
		<div class="about-heading text-center">
			<h6>[ <?php echo get_post_meta(get_the_ID(),'wpcf-video-sub-heading',true);?> ]</h6>
			<h2><?php echo get_post_meta(get_the_ID(),'wpcf-video-heading',true);?></h2>
		</div>
		<a class="play_button" data-fancybox href="<?php echo get_post_meta(get_the_ID(),'wpcf-video-url',true);?>"></a>		
		<h5><?php echo get_post_meta(get_the_ID(),'wpcf-video-tag-line',true);?></h5>
	</div>
</section>