<div class="before_after_section_back">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="portion">
                        <div class="icon_back d-flex justify-content-center align-items-center">
                            <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-before-after-section-main-icon-one',true);?>" alt="">
                        </div>
                        <h2><?php echo get_post_meta(get_the_ID(),'wpcf-before-after-section-heading-one',true);?></h2>
                        <p><?php echo get_post_meta(get_the_ID(),'wpcf-before-after-section-content-one',true);?></p>
                        <div class="custom_button">
                            <a href="<?php echo get_post_meta(get_the_ID(),'wpcf-before-after-section-button-url-one',true);?>">
                                <span></span>
                                <?php echo get_post_meta(get_the_ID(),'wpcf-before-after-section-button-text-one',true);?>
                                <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-before-after-section-button-icon-one',true);?>" alt="">
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                <div class="portion">
                        <div class="icon_back d-flex justify-content-center align-items-center">
                            <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-before-after-section-main-icon-two',true);?>" alt="">
                        </div>
                        <h2><?php echo get_post_meta(get_the_ID(),'wpcf-before-after-section-heading-two',true);?></h2>
                        <p><?php echo get_post_meta(get_the_ID(),'wpcf-before-after-section-content-two',true);?></p>
                        <div class="custom_button">
                            <a href="<?php echo get_post_meta(get_the_ID(),'wpcf-before-after-section-button-url-two',true);?>">
                                <span></span>
                                <?php echo get_post_meta(get_the_ID(),'wpcf-before-after-section-button-text-two',true);?>
                                <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-before-after-section-button-icon-twootwo',true);?>" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>