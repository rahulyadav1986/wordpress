<?php
/*
Custom post type : Services
*/
add_action( 'init', 'create_post_type_services' );
function create_post_type_services() {
  register_post_type( 'services',
    array(
      'labels' => array(
        'name' => __( 'Services' ),
        'singular_name' => __( 'Services' ),
		'add_new_item' => __( 'Add New Services' ),
		'all_items' => __( 'All Services' ),
		'edit_item' => __( 'Edit services' ),
		'new_item' => __( 'New Services' ),
		'search_item' => __( 'Search services' ),
      ),
	  'menu_position'  => 5,
	  'public' => true,
	  'has_archive' => true,
	  'show_ui'            => true,
	  'show_in_menu'       => true,
	  'query_var'          => true,
	   'rewrite'            => array( 'slug' => 'services' ),
	  'taxonomies' => array('category','post_tag','post'),
	  'supports' => array('editor','excerpt','title','thumbnail','page-attributes',),
	  
    )
  );
}
