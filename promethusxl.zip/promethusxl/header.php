<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/main.css">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div class="loader" id="load_screen">
        <div class="text-center">
            <div class="spinner-border" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>

    <header>
        <div class="container">
            <div class="details d-flex justify-content-between align-items-center">
                <a href="<?php echo get_home_url(); ?>"><?php dynamic_sidebar('logo') ?></a>
                <div class="right_details d-flex justify-content-end align-items-center">
                    <?php dynamic_sidebar('h_c_d') ?>                    
                </div>
            </div>

        </div>        
    </header>
    <div class="menu_details mobile-menu" id="menu">
        <div class="container">
		<?php
				wp_nav_menu( array(
				'theme_location'    => 'header-menu',
				'container'  => '',
				'depth'             => 2,
				'items_wrap' => '<ul class="menu">%3$s</ul>' ,
				'menu_class'        => '',
				
				) );
            ?>
        </div>

    </div>








