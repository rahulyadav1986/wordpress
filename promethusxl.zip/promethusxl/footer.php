<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

?>

<footer>
        <?php
				wp_nav_menu( array(
				'theme_location'    => 'header-menu',
				'container'  => '',
				'depth'             => 2,
				'items_wrap' => '<ul class="top_menu">%3$s</ul>' ,
				'menu_class'        => '',
				
				) );
            ?>
        <div class="contact_section">
            <div class="container">
                <?php dynamic_sidebar('f_contact') ?>  
            </div>
        </div>
        <div class="footer_menu_details">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <?php dynamic_sidebar('f_about_details') ?>
                        
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="portion">
                            <h3>Services</h3>
                            <?php
                                wp_nav_menu( array(
                                'theme_location'    => 'services-menu',
                                'container'  => '',
                                'depth'             => 2,
                                'items_wrap' => '<ul class="ft_menu">%3$s</ul>' ,
                                'menu_class'        => '',
                                
                                ) );
                            ?>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="portion">
                            <h3>Procedures</h3>
                            <ul class="ft_menu">
                                <li><a href="">Introduction To Male Enhancement</a></li>
                                <li><a href="">Penile Girth Enlargement</a></li>
                                <li><a href="">Penile Head Enlargement</a></li>
                                <li><a href="">Scrotal Enhancement</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copy_right_details">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5 d-flex align-items-center justify-content-start common">
                            <?php dynamic_sidebar('copyright') ?> 
                        </div>
                        <div class="col-lg-3 d-flex align-items-center common">
                            <a href="<?php echo get_home_url(); ?>"><?php dynamic_sidebar('f_logo') ?></a>
                        </div>
                        <div class="col-lg-4 d-flex align-items-center justify-content-end common">
                            <?php dynamic_sidebar('ft_socials') ?> 
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </footer>






<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery-migrate-1.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.slicknav.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/owl.carousel.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.fancybox.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/app.js"></script>



<?php wp_footer(); ?>

</body>
</html>
